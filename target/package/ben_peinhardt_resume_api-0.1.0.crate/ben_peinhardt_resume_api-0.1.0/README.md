# resume_api_and_bindings
The content of my resume deployed as a REST api, and bindings to that api, all in Rust. Because why not.
